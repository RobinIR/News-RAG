Title: Masked agents, tear gas, and raids: the tactics used in Trump's deportation drive News Scource: BBC Political leaning: Center News type: Broadcast Transcript Published Date: 2 November 2025 Source Link: https://www.bbc.com/news/videos/c6299nrj76yo

[00:01]-&gt;[00:33]

Extraordinary scenes have been playing

Out in ordinary places across the United

States in recent months.

Tear gas and odor been parked.

Wait, you guys came to the school and to

Do this?

&gt;&gt; You have a warrant?

What we're seeing is the result of a key

Campaign promise from Donald Trump.

On Day one I will launch the largest

Deportation program in American history.

Immigration and Customs Enforcement,

Otherwise known as ICE, is the main

Agency implementing his plan to deport

[00:30]-&gt;[01:01]

Millions of undocumented immigrants.

But other departments are also involved,

Including Border Patrol.

[Music]These agents are usually stationed along

America's land borders, but they're

Increasingly being seen making arrests

In US cities.

This is a whole of

Government effort.

We have never seen

Anything like this in the United States

Of America.

This is an unprecedented

Effort to reduce the immigrant

Population in the country.

The Trump Administration has reportedly set ICE a

[00:58]-&gt;[01:28]

Goal of 3,000 arrests a day.

They're Still some way off that, but the

Agency's average monthly arrests under

President Trump are about three times as

High as under President Biden over the

Same period last year.

Trump says anyone who has entered the

Country illegally is a potential target.

Former ICE officials, like John Sandweg,

Who headed the agency under Barack

Obama, say previous administrations

Prioritized arresting those with a

Criminal record.

It'd be much more

Targeted surgical strike.

[01:28]-&gt;[01:59]

Not nearly as Flashy, much lower profile, and far less

Controversial.

Of course, what we're

What has happened here though is the

Administration didn't like that

Approach.

And the reason they didn't

Like that approach is it doesn't result

In large numbers of arrests.

And what This has resulted in is a shift in

Tactics away from these more targeted

Approaches, but just mass arrests of

People.

BBC Verify has gathered more

Than 70 videos shared on social media of

The current crackdown across several

Cities since June.

And we found three tactics being widely

[01:56]-&gt;[02:27]

Used under Trump this term.

Agents concealing their identities.

What Law enforcement agency are you with?

People being arrested outside

Immigration courts and other previously

Protected places.

[Music]And the use of weapons normally

Associated with controlling riots, like

Tear gas, on civilians.

&gt;&gt; Do you see The most widespread tactic we've seen is

Officers hiding their faces.

In more Than 80% of the videos we analyzed, some

Of the officers involved are wearing

[02:25]-&gt;[02:56]

Face coverings.

In seven videos, some agents are seen in

Plain clothing with no clear law

Enforcement ID on display.

They also Often use unmarked vehicles.

Immigration agents have operated

Undercover in the past.

But the widespread use of face coverings

Is new, according to Deborah Flyshaker,

Who was the acting chief of staff at ICE

Under President Biden.

Masking Is not something I've ever seen done

Before.

[02:53]-&gt;[03:23]

Um, these are people we trust to carry

Guns on behalf of the federal

Government.

By being masked and by

Failing to identify yourself, I think

That it is it is making the situation

More dangerous and putting people at

Risk.

The Trump administration says it's

Necessary for the protection of the

Agents.

They report officers and their families

Are being threatened online, and that

They are facing a more than a 1,000%

Increase in assaults, although we can't

Independently verify this figure.

[03:23]-&gt;[03:54]

I'm Going to answer the mask question.

Oh, I'm sorry if people are offended by them

Wearing masks, but I'm not going to let

My officers and agents go out there and

Put their lives on the line and their

Family on the line because people don't

Like what immigration enforcement is.

The second tactical shift is where the

Arrests are taking place.

Before Trump Entered office at the start of this

Year, certain locations were typically

Out of bounds for immigration

Enforcement.

But now we're seeing

Federal agents in hospitals.

[03:50]-&gt;[04:20]

And they patrol immigration courthouses.

When people are coming to court, it's

Because they want to be following the

Process and trying to gain lawful status

In the United States.

It's also because If they don't come to court, they can be

Ordered removed in their absence.

So, It's a catch-22.

We verified several Videos of arrests taking place at 26

[04:18]-&gt;[04:49]

Federal Plaza in New York.

The Immigration courthouse here has become

The epicenter of the crackdown in the

City.

This incident there went viral.

A woman Whose husband had just been detained

Confronts an agent And is thrown to the ground.

[Laughter]The officer was temporarily suspended as

A result.

The third tactic we've analyzed is the

Use of tear gas and other chemical

[04:47]-&gt;[05:18]

Irritants by officers.

We verified footage of them being used

In eight different incidents.

This is a raid in Los Angeles targeting

Suspected illegal immigrants trying to

Pick up construction jobs.

One agent Points pepper spray at someone filming.

Another deploys what appears to be a

Tear gas canister.

Tear gas has also been deployed against

Civilians protesting the crackdown,

Including in these incidents, which

[05:15]-&gt;[05:49]

Happened in Chicago in October.

Earlier in the month, a judge in the

City told agents to stop using such

Weapons on protesters who pose no

Immediate threat, and has raised

Concerns that they still appear to be

Doing so.

Dr.

Rohini Haar has studied the dangers

Of deploying tear gas in civilian

Settings.

It's an indiscriminate weapon,

And so you can't really target that

Towards an individual that's posing a

Threat or is causing harm.

It will hit Everybody in the area.

It appears that They're using it excessively and

[05:47]-&gt;[06:18]

Unnecessarily and Quite disproportionately to what the

Threat is that's being posed.

The Department of Homeland Security says

Far-left protesters have interrupted

Their work.

And they've published video

Showing people throwing objects towards

Agents.

Congress basically handed ICE a

Blank check.

Anything they want to do

Now, they can afford to do.

I think that What we've seen largely up to this point

Has been the opening act, and we're

About to get into the the meat of the

Performance.

Immigration raids and the

[06:16]-&gt;[06:35]

Protest against them show no signs of

Slowing.

Recruitment drives to further

Bolster ICE's ranks are well underway.

That's part of a $75 billion package

Approved for the agency over the next

Four years.

This will make it the

Highest-funded law enforcement body in

The US by far.