Title: Is A Massive ICE Surge Coming To New York? Homan Issues New Threats After State Restricts Cooperation News Source: Forbes Political Leaning: Center News Type: News Published Date: 08 June 2026 Source Link: https://www.forbes.com/sites/saradorn/2026/06/08/is-a-massive-ice-surge-coming-to-new-york-homan-issues-new-threats-after-state-restricts-cooperation/ Topic: Deportation Campaign Topline

Border czar Tom Homan said Monday New York would see an unprecedented surge in ICE agents-a sign the Trump administration is reverting back to its aggressive immigration enforcement tactics after pulling back the effort when federal agents killed two Americans at anti-ICE demonstrations earlier this year.

Key Facts

Homan told Fox News, "you're going to see more ICE agents than you've ever seen in New York City, and it's coming. I just reviewed an operation plan, I'm not going to tell you exactly when it's going to happen, but it's coming."

Homan said the surge is a response to legislation Democratic New York Gov. Kathy Hochul recently signed restricting cooperation between Immigration and Customs Enforcement and state and local authorities.

Homan took particular issue with a provision that prohibits ICE from making arrests at state and local law enforcement facilities, telling Fox News, "now we gotta send a whole team into the neighborhood to find this person that doesn't want to be found."

He claimed he warned Hochul during a meeting in March that if she signed the legislation, he would send more ICE agents to New York-though Hochul said Trump promised governors in February he wouldn't send more federal agents to places they're not wanted.

The legislation signed by Hochul-which would also ban local, state and federal law enforcement from wearing masks when interacting with the public, among other restrictions-was a response to the shooting deaths of Renee Good and Alex Pretti by federal immigration officials earlier this year.

The Trump administration pulled back some of its aggressive immigration enforcement tactics and rhetoric in the wake of the killings, but protests over living conditions at a New Jersey immigration detention center have reignited tensions as demonstrators and law enforcement have engaged in some violent clashes.

Tangent

The legislation passed by Democratic lawmakers in New York and signed by Hochul prohibits state and local law enforcement from entering into official or unofficial cooperation agreements with federal immigration authorities and bars them from using state and local law enforcement personnel and facilities for immigration enforcement purposes. Warrantless searches of hospitals, daycares, schools, churches and polling locations were also banned.

Chief Critic

The Department of Homeland Security has pushed back against New York's new laws and similar crackdowns in other states. DHS told agents in an internal memo last month they are "not legally required to comply with state and local mask prohibitions while carrying out their official duties," The New York Times reported. A similar mask ban enacted by California was struck down because it did not also require state law enforcement to abide by the rule. New York's law applies to local, state and federal law enforcement.

Key Background

The Trump administration retreated on its immigration crackdown in Minneapolis earlier this year in the wake of bipartisan backlash to Pretti and Good's killings, and Trump softened his anti-immigration rhetoric. Violent clashes between protesters and federal immigration officers outside the Delaney Hall immigration detention facility in Newark, New Jersey, have reignited the debate surrounding Trump's immigration enforcement tactics, particularly how federal agents deal with protesters. More than 80 people have been arrested in connection with protests over the living conditions at Delaney Hall, ABC reported Saturday. Video footage and images have shown police in riot gear armed with batons and rifles and using pepper spray and tear gas to disperse protests. The Trump administration has claimed officers have been wounded in clashes with protesters and several demonstrators have been arrested on charges of assaulting officers. Detainees have said they are given moldy and expired food, crowded in hot cells and lack medical care. Democratic members of Congress from New York and New Jersey who visited the facility last month corroborated some of the inmates' claims-Rep. Jerry Nadler, D-N.Y., said inmates are given "very small portions" of food and "very often, there are maggots in the food." DHS has denied the allegations. Homan said he visited the facility and ate the same food as the inmates, and it was a "well-established meal," he told Fox News on Monday.